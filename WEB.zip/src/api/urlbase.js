/**
 *接口域名管理
 */
const base={
  // url:'http://192.168.5.41:8083',//
  // url:'http://192.168.5.100:8083',
  url:'apis',//运行环境跨域
  // url:'',
  
}
export default base;
