var server = {
  ip: "192.168.5.169",
  port: "8079/video",
  path: "/#/questionnaire/"
};
export default server;  
