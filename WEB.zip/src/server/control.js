var control = {
    ip: "192.168.5.169",
    port:'8079',
    path: "/#/questionnaire/"
};
export default control;

