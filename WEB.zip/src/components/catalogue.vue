<template>
    <div class="catalogue">
        <hea :isshow=1></hea>
        <navlist></navlist>
        <div class="auto margin-bot">
            <div class="catatop"><span class="catabtn" @click="addOne"><i class="el-icon-circle-plus-outline"></i> 添加一级目录</span>
            </div>
            <!-- 树状目录 -->
            <div class="tree-wapper">
                <el-tree
                :data="data"
                :props="defaultProps"
                accordion
                :expand-on-click-node="false"
                @node-click="handleNodeClick"
                :highlight-current="true"
                :render-content="renderContent">
                </el-tree>
            </div>
        </div>
        <!-- edirt -->
        <div class="cataedirt" v-show="edirtControl">
            <div class="cataedirt-wapper clearfix">
                <div class="cataedirt-catatop"><span>编辑</span><i @click="edirtHidden" class="el-icon-error fr"></i></div>
                <p class="cata-content"><span>名称：</span><el-input v-model="cataData.name" placeholder="请输入内容" @keyup.enter.native="controlName"></el-input></p>
                <div class="delect-footer">
                  <el-button type="primary" @click="controlName">确定</el-button>
                  <el-button @click="edirtHidden">取消</el-button>
                </div>
            </div>
        </div>
        <!--delect-->
		<div class="delect-wapper" v-show="delectList">
			<div class="delect">
				<div class="delect-top">
					<span class="delect-left">提示</span>
					<span class="delect-right fr"><i  @click="delectH" class="el-icon-close"></i></span>
				</div>
				<div class="delect-text">
					<img src="../images/info.png"/>
					<span>确定删除所选项吗？</span>
				</div>
				<div class="delect-footer">
					<el-button type="primary" @click="del()">确定</el-button>
					<el-button @click="delectH">取消</el-button>
				</div>
			</div>
		</div>
		<!--delect end--> 
    </div>
</template>
<script>
import server from '@/server/server.js'
import ajax from "@/server/ajax.js";
import hea from './header'
import navlist from './nav'
export default {
    name:'catalogue',
    components:{
        hea,
        navlist,
    },
    data() {
      return {
        data:[],
        defaultProps: {
          children: 'childList',
          label: 'name'
        },
        delectList:false,
        edirtControl:false,
        cataData:{
            "childList": [
                {}
            ],
            "id": 0,
            "inserttime": "",
            "name": "",
            "pid": 0,
            "updatetime": ""
        },
        level:1,
        catalogueId:'',
        catalogueName:'',
        addControl:'',

      };
    },
   
    methods: {
      //当前目录
      handleNodeClick(data,node,da) {
        this.level=node.level;//获取当前目录的层级
        // console.log(this.level)
      },
      //获取目录结构
      getTree(){
          const _this=this;
        ajax({
            url:'filedirectory/tree',
        }).then(function(res){
            // console.log(res)
            _this.data=res;
        })
      },
      //目录编辑
      renderContent(h,{node,data,store}) {
        return (
          <span style="flex: 1; display: flex; align-items: center; justify-content: space-between; font-size: 14px; padding-right: 8px;">
            <span>
              <span>{node.label}</span>
            </span>
            <span class="showcontrol">
                <el-button type="primary" on-click={() => this.append(data.id,data.name)} icon="el-icon-plus">新增</el-button>
                <el-button type="info" on-click={() => this.edirt(data.id,data.name,data.pid)} icon="el-icon-edit">编辑</el-button>
                <el-button type="danger" on-click={() => this.delects(data)} icon="el-icon-delete">删除</el-button>
            </span>
          </span>);
      },
      //弹出框
      edirtHidden(){
        this.edirtControl=false;
      },
      //提交弹窗
      controlName(){
          this.edirtControl=false;
          const _this=this;
          if(this.addControl=="add"){//添加
            ajax({
              url:'filedirectory/add',
              type:'POST',
              data:JSON.stringify(_this.cataData),
              contentType: "application/json;charset=UTF-8",
            }).then(function(res){
               _this.getTree()
            })
            
          }else if(this.addControl=="edirt"){//编辑
            ajax({
              url:'filedirectory/update',
              type:'PUT',
              data:JSON.stringify(_this.cataData),
              contentType: "application/json;charset=UTF-8",
            }).then(function(res){
               _this.getTree()
            })
          }else{
            return false;
          }
        // this.edirtControl=false;
      },
      //添加一级目录
      addOne(){
          this.edirtControl=true;
          this.cataData.pid=0;
          this.cataData.name='';  
          this.addControl="add"  
      },
      //添加
      append(id,name){
        const _this=this;
        this.addControl="add";  
        setTimeout(function(){
          if(_this.level>=3){
            _this.$message({
                  showClose: true,
                  message: '目录层级暂时开发三层!',
                  type: 'warning'
              });
          }else{
            _this.edirtControl=true;
            _this.cataData.pid=id; 
            _this.cataData.name=''; 
          }  
        },100)
    
      },
      //编辑
      edirt(id,name,pid){
          this.addControl="edirt"
          this.edirtControl=true;
          this.cataData.id=id;
          this.cataData.pid=pid;
          this.cataData.name=name;
      },
      //删除
      delects(data){
          this.delectList=true;
          this.cataData.pid=data.id;
      },
      del(){
        const _this=this;
        this.delectList=false;
        ajax({
            url:'filedirectory/del'+"/?id="+_this.cataData.pid,
            type:'DELETE',
        }).then(function(res){
            _this.$message({
                showClose: true,
                message: '删除成功!',
                type: 'success'
            });
            _this.getTree()
        })
        
      },
      //删除取消
        delectH(){ 
            this.delectList=false     
        },
      
    },
    mounted(){
        this.getTree();
    }
}
</script>
<style>
.catalogue{min-height: 100%;}
.catatop{color:#f19149;border-bottom: 1px dashed #ccc;padding-bottom: 20px;margin-bottom: 20px;margin-top: 20px;}
.catabtn{border:1px solid #f19149;padding: 5px 12px;cursor: pointer;display: inline-block;font-size: 16px;}
.catalogue .el-tree-node__expand-icon{color: #f19149;font-size: 24px;} 
.catalogue .el-tree-node__expand-icon.is-leaf{color: transparent;}
.catalogue .el-tree-node__label{font-size: 18px;}
.catalogue .el-tree-node__content{height: 32px;}
.tree-wapper{max-width: 800px;}
.tree-wapper .el-button{padding: 4px 20px;}
.showcontrol{display: none;}
.el-tree-node__content:hover .showcontrol{display: block;}
.catalogue .el-input__inner{height: 33px;vertical-align: middle;}
.cataedirt{height: 100%;width: 100%;position: fixed;background:rgba(0,0,0,.3);top: 0;left: 0;color:#333;}
.cataedirt-wapper{position: fixed;top: 50%;left: 50%;width: 500px;box-shadow: 0 0 10px #ccc;transform:translate(-50%,-50%);background: #fff;}
.cataedirt-catatop{line-height: 35px;background: #f7f7f7;font-size: 16px;padding: 5px 8px;color: #303133}
.cataedirt-catatop .el-icon-error{padding-top: 6px;font-size: 18px;color: #707173}
.cata-content{padding: 10px 30px;color: #707173;padding-top: 28px;}
.cata-content .el-input{width: 390px;}
.cataedirt-wapper .delect-footer{padding-right: 32px;}
</style>
